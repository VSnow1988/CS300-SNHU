//============================================================================
// Name        : HashTable.cpp
// Author      : John Watson, edited by Vincent Snow
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : HashTable program to interact with CSV auction data
//============================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string> // stoi
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

const unsigned int DEFAULT_SIZE = 179;

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Hash Table class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a hash table with chaining.
 */
class HashTable {

private:
    // Define structures to hold bids
    struct Node {
        Bid bid;
        unsigned int key;
        Node *next;

        // default constructor
        Node() {
            key = UINT_MAX; //Default value, marks node empty.
            next = nullptr; //A null pointer indicates this node is a tail
        }

        // initialize with a bid
        Node(Bid aBid) : Node() {
            bid = aBid;
        }

        // initialize with a bid and a key
        Node(Bid aBid, unsigned int aKey) : Node(aBid) {
            key = aKey;
        }
    };

    vector<Node> nodes;

    unsigned int tableSize = DEFAULT_SIZE; //Indicate how many vector spaces are the table

    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned int size);
    virtual ~HashTable();
    void Insert(Bid bid);
    void PrintAll();
    void Remove(string bidId);
    Bid Search(string bidId);
};

/**
 * Default constructor
 */
HashTable::HashTable() {
    // Initialize the structures used to hold bids
    for (int i = 0; i < this->tableSize; i++) {
        this->nodes.push_back(Node());//Designate the buckets by filling in with empty head nodes
    }
    // Initalize node structure by resizing tableSize
}

/**
 * Constructor for specifying size of the table
 * Use to improve efficiency of hashing algorithm
 * by reducing collisions without wasting memory.
 */
HashTable::HashTable(unsigned int size) {
    this->tableSize = size;// invoke local tableSize to size with this->
    for (int i = 0; i < this->tableSize; i++) {
        this->nodes.push_back(Node());//Designate the buckets by filling in with empty head nodes
    }// resize nodes size
}


/**
 * Destructor
 */
HashTable::~HashTable() {
    // Logic to free storage when class is destroyed
    delete &nodes; // erase the entire vector of nodes
}

/**
 * Calculate the hash value of a given key.
 * Note that key is specifically defined as
 * unsigned int to prevent undefined results
 * of a negative list index.
 *
 * @param key The key to hash
 * @return The calculated hash
 */
unsigned int HashTable::hash(int key) {
    // logic to calculate a hash value
    int index = key % this->tableSize;
    return index;// return the hashed index
}

/**
 * Insert a bid
 *
 * @param bid The bid to insert
 */
void HashTable::Insert(Bid bid) {
    // Implement logic to insert a bid
    int key = hash(stoi(bid.bidId));// create the key for the given bid
    Node* node = &nodes.at(key);// retrieve node using key
    if (node->key == UINT_MAX) {// if no entry found for the key
        node->bid = bid;
        node->key = key;// assign this node to the key position
    }
    else {// else if node is used
        while (node->next != nullptr) { //find the tail 
            if (node->key == UINT_MAX) {//if empty node, use it
                node->bid = bid;
                node->key = key;
            }
            node = node->next;
        }
        nodes.push_back(Node(bid, key)); // add new Node to end of vector if needed
        node->next = &nodes.at(nodes.size() - 1); // assign tail of bucket to point to new node          
    }
}

/**
 * Print all bids
 */
void HashTable::PrintAll() {
    //logic to print all bids
    for (int i = 0; i < this->tableSize; i++) {// iterate through the buckets
        Node* node = &this->nodes[i]; //get the head node for this bucket
        if (node->key != UINT_MAX) { // special case for first node
            cout << node->key << " | " << node->bid.bidId << " | " << node->bid.title
                << " | " << node->bid.amount << " | " << node->bid.fund << endl;// output key, bidID, title, amount and fund
        }
        while (node->next != nullptr) {// while node not equal to nullptr
            if (node->key != UINT_MAX) {//If it is not empty, print it
                cout << node->next->key << " | " << node->next->bid.bidId << " | " << node->next->bid.title
                    << " | " << node->next->bid.amount << " | " << node->next->bid.fund << endl;// output next key, bidID, title, amount and fund
            }
            node = node->next; //point to next node in list
        }
    }
}

/**
 * Remove a bid
 *
 * @param bidId The bid id to search for
 */
void HashTable::Remove(string bidId) {
    // logic to remove a bid
    int key = hash(stoi(bidId));// hash the bidId
    Node* node = &nodes.at(key);//Retrieve the bucket's starting node
    if (node->bid.bidId == bidId){//special case if first node is the match
        node->key = UINT_MAX; // mark it empty
        cout << "Bid removed." << endl;
        return;
    }
    else if (node->next != nullptr) {//If match not found, go through the list
        while (node->next != nullptr) {//stop before tail node
            if (node->next->bid.bidId == bidId) {//match found on following node
                node->next->key = UINT_MAX; //mark the next node empty
                cout << "Bid removed." << endl;
                return;
            }
        }
    }
    cout << "Bid not found." << endl;
}

/**
 * Search for the specified bidId
 *
 * @param bidId The bid id to search for
 */
Bid HashTable::Search(string bidId) {
    Bid bid;
    // logic to search for and return a bid
    int key = hash(stoi(bidId)); //find the key for the given bid
    Node* node = &this->nodes.at(key); //retrieve the bucket (leading node)
    if (node->bid.bidId == bidId) {//special case if the first in the bucket is a match
        if (node->key != UINT_MAX) {//if not empty
            bid = node->bid;
            return bid;
        }
        else {// if this node has been marked empty
            bid = Bid();
            return bid;
        }
    }
    else {//start searching the bucket for the bid
        while (node->next != nullptr) {//stop before the tail
            if (node->next->key != UINT_MAX) {//if the next node is not empty
                if (node->next->bid.bidId == bidId) {// and it matches the bid ID
                    bid = node->next->bid;//return this bid
                    return bid;
                }
            }
            else { // if node is marked empty
                if (node->next->bid.bidId == bidId) {// and it matches the bid ID
                    bid = Bid();//return empty bid
                    return bid;
                }
            }
        }
        // if no entry found for the key
        bid = Bid();
        return bid;
    }
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, HashTable* hashTable) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            hashTable->Insert(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98190";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98190";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a hash table to hold all the bids
    HashTable* bidTable;

    Bid bid;
    bidTable = new HashTable();
    
    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            
            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadBids(csvPath, bidTable);

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "Bids read." << endl; // FIXME: Display # of bids read
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            bidTable->PrintAll();
            break;

        case 3:
            ticks = clock();

            bid = bidTable->Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
                cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 4:
            bidTable->Remove(bidKey);
            break;
        }
    }

    cout << "Good bye." << endl;

    return 0;
}
