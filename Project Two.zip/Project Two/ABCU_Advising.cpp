//============================================================================
// Name        : Project Two CS300
// Author      : Vincent Snow
// Description : ABCU command-line program to plan course registration.
//============================================================================

#include <iostream>
#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

struct Course { // Holds course information

	string courseNum;
	string courseTitle;
	vector<string> prereqs;
	Course() {
		courseNum = "";
		courseTitle = "";
		prereqs = {};
	}

};

struct Node { // Holds data for the tree

	Course course;
	Node* left = nullptr;
	Node* right = nullptr;

	Node(); // Default constructor
	Node(Course course) { // Construct with a course
		this->course = course;
	};
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

class BinarySearchTree {

private:
	int size;
	Node* root;
	void printinorder(Node*);
	int validateInOrder(Node*);
	void deleteTree(Node* node);


public:
	BinarySearchTree();
	~BinarySearchTree();
	int Size();
	void insert(Course);
	void printInOrder();
	int validate();
	Course search(string);
};

//============================================================================
// Binary Search Tree method definitions
//============================================================================

BinarySearchTree::BinarySearchTree() { // Default constructor, initialize variables.
	size = 0;
	root = nullptr;
};

BinarySearchTree::~BinarySearchTree() { // Destructor, deletes all nodes
	deleteTree(root);
}

void BinarySearchTree::deleteTree(Node* node) { // Private destruction method
	if (node == nullptr) {
		return;
	}
	deleteTree(node->left); // Recursive call to left side
	delete node;
	deleteTree(node->right); // Recursive call to right side
}

int BinarySearchTree::Size() { // Get the size of the tree
	return this->size;
}

void BinarySearchTree::insert(Course course) { // Add a course to the BST
	Node* node = new Node(course); // Create new node in the heap using course data
	Node* current = this->root; // Starting at the root

	if (current == nullptr) { // If the root is empty
		this->root = node; // Point root to the new node
		this->size += 1; // Increment size count
		return; // Finished insertion
	}
	while (current != nullptr) { // Traverse tree to find available node
		if (course.courseNum <= current->course.courseNum) { // Travel left
			if (current->left == nullptr) { // If the left child is empty
				current->left = node; // Insert the node as it's left child
				this->size += 1; // Increment size count
				return; // Finished insertion
			}
			else { // It already has a left child
				current = current->left; // Travel left
			}
		}
		else { // Course is greater than current
			if (current->right == nullptr) { // If the right child is empty
				current->right = node; // Insert the node here
				this->size += 1; // Increment size of tree
				return; // Finished insertion
			}
			else {
				current = current->right; // Travel right
			}
		}
	}
};

Course BinarySearchTree::search(string courseNum) { // Return a specific Course object
	Node* current = this->root; // Start at the root
	while (current != nullptr) { // Look through the tree for the course
		if (current->course.courseNum == courseNum) { // If a match is found
			return current->course; // Return this course
		}
		else if (current->course.courseNum > courseNum) {
			current = current->left; //Travel left
		}
		else { // current courseNum < courseNum
			current = current->right; // Travel right
		}
	}
	return Course(); // Not found
};

int BinarySearchTree::validate() { // Use this public method to access private root data
	return validateInOrder(this->root); // Validate starting at the root
};

int BinarySearchTree::validateInOrder(Node* node) { // Private method that performs the validationg
	// Indicate whether anything was removed
	if (node == nullptr) { // Return once the end of the tree is reached
		return 0; // Tell if completed successfully
	}

	validateInOrder(node->left); // Recursive call on left side
	for (int i = 0; i < node->course.prereqs.size(); i++) { // Go through the node's prereqs
		if (this->search(node->course.prereqs[i]).courseNum.empty()) { // Search for this prereq returns empty 
			node->course.prereqs.erase(node->course.prereqs.begin() + i); // Remove this prerequisite
		}
	}
	validateInOrder(node->right); // Recursive call on right side
};

void BinarySearchTree::printInOrder() { // Use public method to access private root data
	printinorder(this->root);
};

void BinarySearchTree::printinorder(Node* node) {//Private method for printing
	if (node == nullptr) {
		return;
	}
	printinorder(node->left); // Recursive call to left side
	cout << node->course.courseNum << ", " << node->course.courseTitle << endl; // Print the course data
	printinorder(node->right); // Recursive call to right side
};

//============================================================================
// Program global functions
//============================================================================

void loadData(string csvPath, BinarySearchTree* bst) { // Load the data from csv into BST

	Course course = Course();
	bool errors = false;
	bool lineErrors = false;
	int curChar = 0;
	string prereq = "";
	string line = "";
	ifstream file;

	file.open(csvPath);
	if (file.is_open() && file.good()) { // Check if file is open properly
		cout << "Loading courses..." << endl;
		while (!file.eof()) { // While not at end of file

			// Ensure all the variables are reset before reading a new line to avoid errors
			line, prereq = "";
			course = Course();
			curChar = 0;
			errors, lineErrors = false;

			getline(file, line); // Read single line 
			//Split the string into data fields
			for (curChar; curChar < line.length(); curChar++) { // Fill the first field, courseNum
				if (line.at(curChar) == ',') {
					break; // Go to next loop, comma was found
				}
				else if (!isalpha(line.at(curChar)) && !isdigit(line.at(curChar))) { // This line is formatted improperly
					lineErrors = true;
					break;
				}
				else { // Passed validation, not a comma
					course.courseNum.push_back(line.at(curChar)); // Add character to string of course's number
				}
			};
			if (lineErrors == true) { // If this line did not pass validation
				errors = true; // Set indicator for total errors
				lineErrors = false; // Reset this indicator for reading next field
				continue; // Skip and read the next line
			}
			curChar += 1; //Go to next character after comma
			for (curChar; curChar < line.length(); curChar++) { // Fill the courseTitle field
				if (line[curChar] != ',') {
					course.courseTitle.push_back(line[curChar]); // Add character to string of course's number
				}
				else { // This character is a comma
					break; // Go to next field
				}
			};
			curChar += 1; //Go to next character after comma
			for (curChar; curChar < line.length(); curChar++) { // Start adding prereqs
				if (line.at(curChar) == ',') { // Comma found
					if (prereq.length() != 7) { // If the prereq is not valid 7 characters long
						lineErrors = true;
					}
					else { // Check for non-alphanumeric characters if it passed the length check
						for (int i = 0; i < prereq.length(); i++) {
							if (!isalpha(prereq.at(i)) && !isdigit(prereq.at(i))) {
								lineErrors = true;
							}
						}
					}
					if (!lineErrors) { // If format was valid
						course.prereqs.push_back(prereq); // Add this prereq
						prereq = ""; // Reset the holding string
					}
				}
				else if (curChar == (line.length() - 1)) { // This is not a comma, but is the last character in the line
					prereq.push_back(line.at(curChar)); // Add this character to the string
					course.prereqs.push_back(prereq); // Add this prereq
					prereq = ""; // Reset the holding string
				}
				else { // This is not a comma or last character
					prereq.push_back(line.at(curChar)); // Concatenate character to prereq string
				}
			};
			bst->insert(course); // Insert this course to the binary tree
		};
		cout << bst->Size() << " total courses loaded." << endl; // Data structure loaded.
		if (errors) { // Courtesy message if any lines were skipped
			cout << "Some data was formatted incorrectly and not read. Please update file." << endl;
		}
		cout << "Checking prerequisites..." << endl;

		bst->validate(); // Validate the prerequisites 
		cout << "All invalid prerequisites were ignored. Finished loading data." << endl; // Notify user that the process is finished
		file.close(); // Finished with read
	}
	else { // Problem loading the file
		cout << "Could not find or read specified file." << endl;
	}
}

int main() {

	BinarySearchTree* bst = new BinarySearchTree(); // Create the data structure
	string inputString;
	int choice = 0;
	string csvPath;
	string courseNum;
	Course course;

	while (choice != 9) {
		cout << "Menu:" << endl;
		cout << "  1. Load Data Structure." << endl;
		cout << "  2. Print Course List." << endl;
		cout << "  3. Print Course." << endl;
		cout << "  9. Exit" << endl;
		cout << "What would you like to do? ";
		cin >> inputString;
		try {
			choice = stoi(inputString); // Handle accidental entering of multiple characters
		}
		catch (...) {
			cout << "Not a valid option." << endl;
			continue;
		}

		switch (choice) {

		case 1:

			cout << "Enter the name of the CSV file to use: "; // Get user input for filename
			cin >> csvPath;

			loadData(csvPath, bst); // Load data from input path. Multiple files can be added to the tree.
			break;

		case 2:

			bst->printInOrder(); // Print the whole sorted list of courses
			break;

		case 3:

			//Prompt user to input course number to courseNum
			cout << "What course would you like to know about? ";
			cin >> courseNum;
			transform(courseNum.begin(), courseNum.end(), courseNum.begin(), ::toupper);
			course = bst->search(courseNum);

			if (!course.courseNum.empty()) {
				cout << course.courseNum << ", " << course.courseTitle << endl;
				cout << "Prerequisites: ";
				for (int i = 0; i < course.prereqs.size(); i++) { // Loop to print prereqs
					cout << course.prereqs.at(i);
					if (i < (course.prereqs.size() - 1)) { // If not the last in the line
						cout << ", ";
					}
				}
				cout << endl;
			}
			else {
				cout << "Course number " << courseNum << " not found." << endl;
			}

			break;

		case 9:
			cout << "Thank you for using the course planner!" << endl;
			break;

		default: // If any invalid number is entered
			cout << choice << " is not a valid option." << endl;

		}
	}

	return 0; // End the program after 9 is entered
}