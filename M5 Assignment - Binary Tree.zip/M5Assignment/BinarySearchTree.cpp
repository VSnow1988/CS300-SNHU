//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : edited by Vincent Snow
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Sort and manipulate auction data from a CSV using a binary search tree.
//============================================================================

#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// Internal structure for tree node
struct Node {
    Bid bid;
    Node *left;
    Node *right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a bid
    Node(Bid aBid) :
            Node() {
        bid = aBid;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    Node* removeNode(Node* node, string bidId);

    void postOrder(Node* node);

    void preOrder(Node* node);

    int size;

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void PostOrder();
    void PreOrder();
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
    int Size();
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    root = nullptr; //root is equal to nullptr
    size = 0;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    if (this->root == nullptr) { // Base case, tree is completely empty
        return;
    }
    Node* current = this->root; // Start at the root
    while (current->left != nullptr || current->right != nullptr) {//Find a leaf
        if (current->left != nullptr) { // Go left first
            current == current->left;
        }
        else { // GO right if no left child
            current = current->right;
        }
    }
    delete current; // Delete the leaf
    this->~BinarySearchTree(); // Repeat
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {// Calls private method inOrder(root) since the root node is private data
    this->inOrder(this->root);
}

void BinarySearchTree::inOrder(Node* node) { // Private method called by InOrder()
    if (node == nullptr) {
        return;
    }
    inOrder(node->left);
    cout << node->bid.bidId << ": " << node->bid.title << ", Fund: " << node->bid.fund << ", Amount: " << node->bid.amount << endl; // Print node
    inOrder(node->right);
}

/**
 * Traverse the tree in post-order
 */
void BinarySearchTree::PostOrder() {
    this->postOrder(this->root); //call private method on root
}

/**
 * Traverse the tree in pre-order
 */
void BinarySearchTree::PreOrder() {
    this->preOrder(this->root); //call private method with root
}

/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Bid bid) {
    Node *newNode = new Node(bid); //Make a new node in the heap
    Node* current = this->root; //Initialize the current node pointer
    if (this->root == nullptr) { //If the root is null, start the tree.
        this->root = newNode;
        this->size += 1;
        return;
    }
    while (current != nullptr) { //Traverse the tree
        if (bid.bidId <= current->bid.bidId) { //If key is <= current, search left.
            if (current->left == nullptr) { //If left child is empty, insert node.
                current->left = newNode;
                this->size += 1;
                return;
            }
            else { //If left child is not empty, travel left in the tree.
                current = current->left;
            }
        }
        else { //If bidID is greater than current
            if (current->right == nullptr) { //If there is no right child, insert node.
                current->right = newNode;
                this->size += 1;
                return;
            }
            else { //If there is a right child, travel right along the tree.
                current = current->right;
            }
        }
    }
}

/**
 * Remove a bid
 */
void BinarySearchTree::Remove(string bidId) {
    Node* parent = nullptr;
    Node* current = this->root;
	while (current != nullptr){
		if (current->bid.bidId == bidId){ //found the node
			if (current->left == nullptr && current->right == nullptr) {//this is a leaf
                if (parent == nullptr) { //this is the root also, delete and reset pointer
                    delete this->root;
                }
                else if (parent->left->bid.bidId == current->bid.bidId) {
                    delete parent->left;
                }
                else {//if there are duplicates, delete only one of them
                    delete parent->right;
                }
            }
            else if (current->right == nullptr){
                if (parent == nullptr) { //node is root
                    this->root = current->left;
                }
                else if (parent->left->bid.bidId == current->bid.bidId) {
                    parent->left = current->left;
                    delete current;
                }
                else {
                    parent->right = current->left;
                    delete current;
                }
            }
			else if (current->left == nullptr) { 
                if (parent == nullptr) { //node is root
                    this->root = current->right;
                }
                else if (parent->left->bid.bidId == current->bid.bidId) {
                    parent->left = current->right;
                    delete current;
                }
                else {
                    parent->right = current->right;
                    delete current;
                }
            }
            else {
				// Find the successor node
                Node* successor = current->right;
                while (successor->left != nullptr) {
                    successor = successor->left;
                }
                Node successorCopy = *successor;
                this->Remove(successor->bid.bidId); // Remove it with recursive call
                current = &successorCopy;
            }
            return; // Finished removal
        }
        else if (current->bid.bidId < bidId) { // Search right
            parent = current;
            current = current->right;
        }
        else { // Search left
            parent = current;
            current = current->left;
        }
    }
    return; // Node not found
}

/**
 * Search for a bid
 */
Bid BinarySearchTree::Search(string bidId) {
    Node* current = this->root; // Start at the root
	while (current != nullptr){
        if (current->bid.bidId == bidId) {
            return current->bid; // Found it
        }
        else if (bidId < current->bid.bidId) {
            current = current->left;
        }
        else { // key Bidid > bidId
            current = current->right;
        }
    }
    Bid bid;
    return bid; // Not found, return null bid
}

int BinarySearchTree::Size() {// Return the size of the tree
    return this->size;
}

/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */

void BinarySearchTree::addNode(Node* node, Bid bid) {
    if (node->bid.bidId > bid.bidId) {// if node is larger then add to left
        if (node->left == nullptr) {// if no left node
            node->left = new Node(bid);// this node becomes left
        }
        else {// else recurse down the left node
            addNode(node->left, bid);
        }
    }
    else {
        if (node->right == nullptr) {// if no right node
           node->right = new Node(bid); // this node becomes right
        }
        else {
            addNode(node->right, bid);  // recurse down the left node
        }
    }
}

/**
 * Remove a bid from some node (recursive)
 */
Node* BinarySearchTree::removeNode(Node* node, string bidId) {
    Node* current = node;
    if (node == nullptr) {// if node is nullptr return node
        return node;
    }
    else if (bidId < current->bid.bidId) {// else if bidId < current bid recurse down the left subtree

    }
    else if (bidId < current->bid.bidId) {// else if bidId > current bid recurse down the right subtree

    }
    else {
        if (node->left == nullptr && node->right == nullptr) {  // if no children so node is a leaf node
            delete node;
            node == nullptr; // delete node then set node to nullptr
        }
        else if (node->left != nullptr && node->right == nullptr) {   // else if there's one child to the left
            Node* temp = node;
            node = node->left;
            delete temp;// store node values in temp, set node to child to the left, delete temp node 
        }
        else if (node->right != nullptr && node->left == nullptr) {   // else if one child to the right
            Node* temp = node;
            node = node->right;
            delete temp; // store node values in temp, set node to child to right, delete temp node
        }
        else if (node->right != nullptr && node->left != nullptr) {   // else there are two children
            Node* temp = node->right;         // store right node in temp

            while (node->left != nullptr) { // traverse left to find the minimum (while loop)
                temp = temp->left;     // set temp to left
            }
            bidId = temp->bid.bidId;    // set bid to temp (minimum)
            removeNode(temp, bidId);    // recurse down the right subtree
        }
    }

    return node;//return node
}

void BinarySearchTree::postOrder(Node* node) {
    if (node == nullptr) {
        return;
    }
    postOrder(node->left);
    postOrder(node->right);
    cout << node->bid.bidId << ": " << node->bid.title << ", Fund: " << node->bid.fund << ", Amount: " << node->bid.amount << endl; // Print node
}

void BinarySearchTree::preOrder(Node* node) {
    if (node == nullptr) {
        return;
    }
    cout << node->bid.bidId << ": " << node->bid.title << ", Fund: " << node->bid.fund << ", Amount: " << node->bid.amount << endl; // Print node
    preOrder(node->left);
    preOrder(node->right);
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    //vector<string> header = file.getHeader();
    //for (auto const& c : header) {
    //    cout << c << " | ";
    //}
    //cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            bst->Insert(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98005";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98005";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all bids
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            
            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadBids(csvPath, bst);

            cout << bst->Size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            bst->InOrder();
            break;

        case 3:
            ticks = clock();

            bid = bst->Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 4:
            bst->Remove(bidKey);
            cout << "Bid " << bidKey << " removed." << endl;
            break;
        }
    }

    cout << "Good bye." << endl;

	return 0;
}
